"""Font-related proxy objects."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from docx.dml.color import ColorFormat
from docx.enum.text import WD_FONT_HINT, WD_SHADING_PATTERN, WD_UNDERLINE
from docx.shared import ElementProxy, Emu

if TYPE_CHECKING:
    from docx.enum.text import WD_COLOR_INDEX
    from docx.oxml.text.run import CT_R
    from docx.shared import Length, RGBColor
    from docx.theme import Theme


class Font(ElementProxy):
    """Proxy object for parent of a `<w:rPr>` element and providing access to
    character properties such as font name, font size, bold, and subscript."""

    def __init__(self, r: CT_R, parent: Any | None = None):
        super().__init__(r, parent)
        self._element = r
        self._r = r

    @property
    def all_caps(self) -> bool | None:
        """Read/write.

        Causes text in this font to appear in capital letters.
        """
        return self._get_bool_prop("caps")

    @all_caps.setter
    def all_caps(self, value: bool | None) -> None:
        self._set_bool_prop("caps", value)

    @property
    def bold(self) -> bool | None:
        """Read/write.

        Causes text in this font to appear in bold.
        """
        return self._get_bool_prop("b")

    @bold.setter
    def bold(self, value: bool | None) -> None:
        self._set_bool_prop("b", value)

    @property
    def color(self):
        """A |ColorFormat| object providing a way to get and set the text color for this
        font."""
        return ColorFormat(self._element)

    @property
    def complex_script(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the characters in the run to be treated as complex script
        regardless of their Unicode values.
        """
        return self._get_bool_prop("cs")

    @complex_script.setter
    def complex_script(self, value: bool | None) -> None:
        self._set_bool_prop("cs", value)

    @property
    def cs_bold(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the complex script characters in the run to be displayed in
        bold typeface.
        """
        return self._get_bool_prop("bCs")

    @cs_bold.setter
    def cs_bold(self, value: bool | None) -> None:
        self._set_bool_prop("bCs", value)

    @property
    def cs_italic(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the complex script characters in the run to be displayed in
        italic typeface.
        """
        return self._get_bool_prop("iCs")

    @cs_italic.setter
    def cs_italic(self, value: bool | None) -> None:
        self._set_bool_prop("iCs", value)

    @property
    def cs_name(self) -> str | None:
        """The typeface name applied to complex-script characters in this run.

        `w:rFonts` has four independent typeface slots and Word chooses between them per
        character, according to the script that character belongs to. This is the slot
        used for Arabic, Hebrew and other complex scripts. |None| indicates the typeface
        is inherited from the style hierarchy.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.rFonts_cs

    @cs_name.setter
    def cs_name(self, value: str | None) -> None:
        self._element.get_or_add_rPr().rFonts_cs = value

    @property
    def cs_size(self) -> Length | None:
        """The font size applied to complex-script characters in this run.

        Word tracks this separately from `.size`, in `w:szCs`. |None| indicates the size
        is inherited from the style hierarchy.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.szCs_val

    @cs_size.setter
    def cs_size(self, emu: Length | None) -> None:
        self._element.get_or_add_rPr().szCs_val = emu

    @property
    def east_asia_name(self) -> str | None:
        """The typeface name applied to East Asian characters in this run.

        This is the slot that carries the meaningful typeface for Chinese, Japanese and
        Korean text; see `.cs_name` for the four-slot arrangement. |None| indicates the
        typeface is inherited from the style hierarchy.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.rFonts_eastAsia

    @east_asia_name.setter
    def east_asia_name(self, value: str | None) -> None:
        self._element.get_or_add_rPr().rFonts_eastAsia = value

    @property
    def hint(self) -> WD_FONT_HINT | None:
        """Member of :ref:`WdFontHint`, or |None| when no hint is specified.

        Tells Word which typeface slot to prefer for a character that belongs to no
        particular script, such as a space or a digit. This matters for correct East
        Asian rendering, where an unhinted run mixes typefaces mid-word.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.rFonts_hint

    @hint.setter
    def hint(self, value: WD_FONT_HINT | None) -> None:
        self._element.get_or_add_rPr().rFonts_hint = value

    @property
    def double_strike(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the text in the run to appear with double strikethrough.
        """
        return self._get_bool_prop("dstrike")

    @double_strike.setter
    def double_strike(self, value: bool | None) -> None:
        self._set_bool_prop("dstrike", value)

    @property
    def emboss(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the text in the run to appear as if raised off the page in
        relief.
        """
        return self._get_bool_prop("emboss")

    @emboss.setter
    def emboss(self, value: bool | None) -> None:
        self._set_bool_prop("emboss", value)

    @property
    def hidden(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the text in the run to be hidden from display, unless
        applications settings force hidden text to be shown.
        """
        return self._get_bool_prop("vanish")

    @hidden.setter
    def hidden(self, value: bool | None) -> None:
        self._set_bool_prop("vanish", value)

    @property
    def highlight_color(self) -> WD_COLOR_INDEX | None:
        """Color of highlighing applied or |None| if not highlighted."""
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.highlight_val

    @highlight_color.setter
    def highlight_color(self, value: WD_COLOR_INDEX | None):
        rPr = self._element.get_or_add_rPr()
        rPr.highlight_val = value

    @property
    def italic(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the text of the run to appear in italics. |None| indicates
        the effective value is inherited from the style hierarchy.
        """
        return self._get_bool_prop("i")

    @italic.setter
    def italic(self, value: bool | None) -> None:
        self._set_bool_prop("i", value)

    @property
    def imprint(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the text in the run to appear as if pressed into the page.
        """
        return self._get_bool_prop("imprint")

    @imprint.setter
    def imprint(self, value: bool | None) -> None:
        self._set_bool_prop("imprint", value)

    @property
    def math(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, specifies this run contains WML that should be handled as though it
        was Office Open XML Math.
        """
        return self._get_bool_prop("oMath")

    @math.setter
    def math(self, value: bool | None) -> None:
        self._set_bool_prop("oMath", value)

    @property
    def name(self) -> str | None:
        """The typeface name for this |Font|.

        Causes the text it controls to appear in the named font, if a matching font is
        found. |None| indicates the typeface is inherited from the style hierarchy.

        This is the `w:ascii` slot of `w:rFonts`, and assigning to it also sets
        `w:hAnsi`, which is what Word does. It deliberately does *not* fall back to the
        other slots: a run can name a different typeface for East Asian
        (`.east_asia_name`) and complex-script (`.cs_name`) characters, Word picks
        between them per character, and reporting one of them as "the" font would be an
        approximation dressed up as an answer. A run with only `w:eastAsia` set
        therefore reports |None| here and its typeface through `.east_asia_name`.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.rFonts_ascii

    @name.setter
    def name(self, value: str | None) -> None:
        rPr = self._element.get_or_add_rPr()
        rPr.rFonts_ascii = value
        rPr.rFonts_hAnsi = value

    @property
    def theme(self) -> str | None:
        """The theme typeface slot for this |Font|, e.g. "minorHAnsi".

        The named slot is resolved against the document theme, so the text follows the
        theme font rather than a font named outright. |None| indicates no theme typeface
        is assigned and the typeface is inherited from the style hierarchy.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.rFonts_asciiTheme

    @theme.setter
    def theme(self, value: str | None) -> None:
        rPr = self._element.get_or_add_rPr()
        rPr.rFonts_asciiTheme = value
        rPr.rFonts_hAnsiTheme = value

    @property
    def theme_typeface(self) -> str | None:
        """The concrete typeface this font's theme slot resolves to, or |None|.

        :attr:`theme` gives the token — ``"minorHAnsi"`` — and this gives the font name
        it stands for, by looking the token up in the document's theme part::

            >>> run.font.theme
            'minorHAnsi'
            >>> run.font.theme_typeface
            'Calibri'

        |None| when the run has no theme slot, when the document carries no theme part,
        or when the theme leaves that slot empty. This resolves the run's *own* theme
        token only; it does not walk the style hierarchy, so a run whose theme font comes
        from its style reads |None| here as it does from :attr:`theme`.
        """
        theme_token = self.theme
        if theme_token is None:
            return None
        theme = self._theme
        return None if theme is None else theme.typeface(theme_token)

    @property
    def _theme(self) -> Theme | None:
        """The theme of the document this font belongs to, or |None|.

        |None| both for a document with no theme part and for a |Font| built over a bare
        element with no part behind it, as the unit tests do.
        """
        try:
            part = self.part
        except (AttributeError, ValueError, NotImplementedError):
            return None
        return getattr(part.package.main_document_part, "theme", None) if part.package else None

    @property
    def scaling(self) -> int | None:
        """Horizontal character scaling, as a whole percentage of normal width.

        100 is normal width, 200 stretches each glyph to double width and 50 condenses
        it to half. Valid values run from 1 to 600. |None| indicates the value is
        inherited from the style hierarchy.

        Note this scales glyphs horizontally only; use `.size` to change font height.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.w_val

    @scaling.setter
    def scaling(self, value: int | None) -> None:
        rPr = self._element.get_or_add_rPr()
        rPr.w_val = value

    @property
    def shading_fill(self) -> RGBColor | str | None:
        """Background shading color behind the text of this run.

        An |RGBColor| value, the string "auto", or |None| when no shading is applied.
        Assigning a hex string such as "FF0000" or "#FF0000" is also accepted.

        This is distinct from `.highlight_color`, which takes a |WD_COLOR_INDEX| member
        and is limited to Word's fixed highlighter palette. Shading accepts any RGB
        value. Word renders both, with highlighting drawn over shading.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.shd_fill

    @shading_fill.setter
    def shading_fill(self, value: RGBColor | str | None) -> None:
        rPr = self._element.get_or_add_rPr()
        rPr.shd_fill = value

    @property
    def shading_pattern(self) -> WD_SHADING_PATTERN | None:
        """The pattern drawn over the shading behind the text of this run.

        A |WD_SHADING_PATTERN| member, or |None| when no shading is applied. Word writes
        |WD_SHADING_PATTERN.CLEAR| for an ordinary background color, which is what
        `.shading_fill` produces on its own.

        Assigning |None| removes the shading entirely, the same as assigning |None| to
        `.shading_fill`.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.shd_val

    @shading_pattern.setter
    def shading_pattern(self, value: WD_SHADING_PATTERN | None) -> None:
        self._element.get_or_add_rPr().shd_val = value

    @property
    def shading_color(self) -> RGBColor | str | None:
        """The foreground color of the shading pattern behind the text of this run.

        An |RGBColor| value, the string "auto", or |None|. This is the color the
        `.shading_pattern` is drawn *in*; `.shading_fill` is the color behind it. For
        the usual |WD_SHADING_PATTERN.CLEAR| pattern nothing is drawn and this has no
        visible effect.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.shd_color

    @shading_color.setter
    def shading_color(self, value: RGBColor | str | None) -> None:
        self._element.get_or_add_rPr().shd_color = value

    @property
    def no_proof(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, specifies that the contents of this run should not report any
        errors when the document is scanned for spelling and grammar.
        """
        return self._get_bool_prop("noProof")

    @no_proof.setter
    def no_proof(self, value: bool | None) -> None:
        self._set_bool_prop("noProof", value)

    @property
    def outline(self) -> bool | None:
        """Read/write tri-state value.

        When |True| causes the characters in the run to appear as if they have an
        outline, by drawing a one pixel wide border around the inside and outside
        borders of each character glyph.
        """
        return self._get_bool_prop("outline")

    @outline.setter
    def outline(self, value: bool | None) -> None:
        self._set_bool_prop("outline", value)

    @property
    def rtl(self) -> bool | None:
        """Read/write tri-state value.

        When |True| causes the text in the run to have right-to-left characteristics.
        """
        return self._get_bool_prop("rtl")

    @rtl.setter
    def rtl(self, value: bool | None) -> None:
        self._set_bool_prop("rtl", value)

    @property
    def shadow(self) -> bool | None:
        """Read/write tri-state value.

        When |True| causes the text in the run to appear as if each character has a
        shadow.
        """
        return self._get_bool_prop("shadow")

    @shadow.setter
    def shadow(self, value: bool | None) -> None:
        self._set_bool_prop("shadow", value)

    @property
    def size(self) -> Length | None:
        """Font height in English Metric Units (EMU).

        |None| indicates the font size should be inherited from the style hierarchy.
        |Length| is a subclass of |int| having properties for convenient conversion into
        points or other length units. The :class:`docx.shared.Pt` class allows
        convenient specification of point values::

            >>> font.size = Pt(24)
            >>> font.size
            304800
            >>> font.size.pt
            24.0

        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.sz_val

    @size.setter
    def size(self, emu: int | Length | None) -> None:
        rPr = self._element.get_or_add_rPr()
        rPr.sz_val = None if emu is None else Emu(emu)

    @property
    def small_caps(self) -> bool | None:
        """Read/write tri-state value.

        When |True| causes the lowercase characters in the run to appear as capital
        letters two points smaller than the font size specified for the run.
        """
        return self._get_bool_prop("smallCaps")

    @small_caps.setter
    def small_caps(self, value: bool | None) -> None:
        self._set_bool_prop("smallCaps", value)

    @property
    def snap_to_grid(self) -> bool | None:
        """Read/write tri-state value.

        When |True| causes the run to use the document grid characters per line settings
        defined in the docGrid element when laying out the characters in this run.
        """
        return self._get_bool_prop("snapToGrid")

    @snap_to_grid.setter
    def snap_to_grid(self, value: bool | None) -> None:
        self._set_bool_prop("snapToGrid", value)

    @property
    def spec_vanish(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, specifies that the given run shall always behave as if it is
        hidden, even when hidden text is being displayed in the current document. The
        property has a very narrow, specialized use related to the table of contents.
        Consult the spec (§17.3.2.36) for more details.
        """
        return self._get_bool_prop("specVanish")

    @spec_vanish.setter
    def spec_vanish(self, value: bool | None) -> None:
        self._set_bool_prop("specVanish", value)

    @property
    def strike(self) -> bool | None:
        """Read/write tri-state value.

        When |True| causes the text in the run to appear with a single horizontal line
        through the center of the line.
        """
        return self._get_bool_prop("strike")

    @strike.setter
    def strike(self, value: bool | None) -> None:
        self._set_bool_prop("strike", value)

    @property
    def subscript(self) -> bool | None:
        """Boolean indicating whether the characters in this |Font| appear as subscript.

        |None| indicates the subscript/subscript value is inherited from the style
        hierarchy.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.subscript

    @subscript.setter
    def subscript(self, value: bool | None) -> None:
        rPr = self._element.get_or_add_rPr()
        rPr.subscript = value

    @property
    def superscript(self) -> bool | None:
        """Boolean indicating whether the characters in this |Font| appear as
        superscript.

        |None| indicates the subscript/superscript value is inherited from the style
        hierarchy.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr.superscript

    @superscript.setter
    def superscript(self, value: bool | None) -> None:
        rPr = self._element.get_or_add_rPr()
        rPr.superscript = value

    @property
    def underline(self) -> bool | WD_UNDERLINE | None:
        """The underline style for this |Font|.

        The value is one of |None|, |True|, |False|, or a member of :ref:`WdUnderline`.

        |None| indicates the font inherits its underline value from the style hierarchy.
        |False| indicates no underline. |True| indicates single underline. The values
        from :ref:`WdUnderline` are used to specify other outline styles such as double,
        wavy, and dotted.
        """
        rPr = self._element.rPr
        if rPr is None:
            return None
        val = rPr.u_val
        return (
            None
            if val == WD_UNDERLINE.INHERITED
            else True
            if val == WD_UNDERLINE.SINGLE
            else False
            if val == WD_UNDERLINE.NONE
            else val
        )

    @underline.setter
    def underline(self, value: bool | WD_UNDERLINE | None) -> None:
        rPr = self._element.get_or_add_rPr()
        # -- works fine without these two mappings, but only because True == 1 and
        # -- False == 0, which happen to match the mapping for WD_UNDERLINE.SINGLE
        # -- and .NONE respectively.
        val = (
            WD_UNDERLINE.SINGLE if value is True else WD_UNDERLINE.NONE if value is False else value
        )
        rPr.u_val = val

    @property
    def web_hidden(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, specifies that the contents of this run shall be hidden when the
        document is displayed in web page view.
        """
        return self._get_bool_prop("webHidden")

    @web_hidden.setter
    def web_hidden(self, value: bool | None) -> None:
        self._set_bool_prop("webHidden", value)

    def _get_bool_prop(self, name: str) -> bool | None:
        """Return the value of boolean child of `w:rPr` having `name`."""
        rPr = self._element.rPr
        if rPr is None:
            return None
        return rPr._get_bool_val(name)  # pyright: ignore[reportPrivateUsage]

    def _set_bool_prop(self, name: str, value: bool | None):
        """Assign `value` to the boolean child `name` of `w:rPr`."""
        rPr = self._element.get_or_add_rPr()
        rPr._set_bool_val(name, value)  # pyright: ignore[reportPrivateUsage]
