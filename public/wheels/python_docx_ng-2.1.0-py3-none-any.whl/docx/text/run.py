"""Run-related proxy objects for python-docx, Run in particular."""

from __future__ import annotations

import os
from typing import IO, TYPE_CHECKING, Iterator, List, cast

from docx.drawing import Drawing
from docx.enum.shape import (
    WD_ANCHOR_RELATIVE_FROM_H,
    WD_ANCHOR_RELATIVE_FROM_V,
    WD_WRAP_TYPE,
)
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_BREAK
from docx.oxml.deletion import delete_element
from docx.oxml.drawing import CT_Drawing
from docx.oxml.text.pagebreak import CT_LastRenderedPageBreak
from docx.shape import FloatingShape, InlineShape
from docx.shared import StoryChild
from docx.styles.style import CharacterStyle
from docx.text.font import Font
from docx.text.pagebreak import RenderedPageBreak

if TYPE_CHECKING:
    import docx.types as t
    from docx.bookmark import Bookmark
    from docx.enum.text import WD_UNDERLINE
    from docx.footnotes import Endnote, Footnote
    from docx.object import EmbeddedObject
    from docx.oxml.text.run import CT_R, CT_Text
    from docx.shared import Length
    from docx.text.paragraph import Paragraph


class Run(StoryChild):
    """Proxy object wrapping `<w:r>` element.

    Several of the properties on Run take a tri-state value, |True|, |False|, or |None|.
    |True| and |False| correspond to on and off respectively. |None| indicates the
    property is not specified directly on the run and its effective value is taken from
    the style hierarchy.
    """

    def __init__(self, r: CT_R, parent: t.ProvidesStoryPart):
        super().__init__(parent)
        self._r = self._element = self.element = r

    def add_break(self, break_type: WD_BREAK = WD_BREAK.LINE):
        """Add a break element of `break_type` to this run.

        `break_type` can take the values `WD_BREAK.LINE`, `WD_BREAK.PAGE`, and
        `WD_BREAK.COLUMN` where `WD_BREAK` is imported from `docx.enum.text`.
        `break_type` defaults to `WD_BREAK.LINE`.
        """
        type_, clear = {
            WD_BREAK.LINE: (None, None),
            WD_BREAK.PAGE: ("page", None),
            WD_BREAK.COLUMN: ("column", None),
            WD_BREAK.LINE_CLEAR_LEFT: ("textWrapping", "left"),
            WD_BREAK.LINE_CLEAR_RIGHT: ("textWrapping", "right"),
            WD_BREAK.LINE_CLEAR_ALL: ("textWrapping", "all"),
        }[break_type]
        br = self._r.add_br()
        if type_ is not None:
            br.type = type_
        if clear is not None:
            br.clear = clear

    def add_picture(
        self,
        image_path_or_stream: str | os.PathLike[str] | IO[bytes],
        width: int | Length | None = None,
        height: int | Length | None = None,
        description: str | None = None,
        title: str | None = None,
        svg_fallback: str | os.PathLike[str] | IO[bytes] | None = None,
        honor_exif_orientation: bool = True,
    ) -> InlineShape:
        """Return |InlineShape| containing image identified by `image_path_or_stream`.

        The picture is added to the end of this run.

        `image_path_or_stream` can be a path (a string) or a file-like object containing
        a binary image.

        If neither width nor height is specified, the picture appears at
        its native size. If only one is specified, it is used to compute a scaling
        factor that is then applied to the unspecified dimension, preserving the aspect
        ratio of the image. The native size of the picture is calculated using the dots-
        per-inch (dpi) value specified in the image file, defaulting to 72 dpi if no
        value is specified, as is often the case.

        `description` is the picture's alternative text, which is what a screen reader
        announces and what an accessibility check looks for. `title` is the separate,
        rarely-used caption-like field Word writes alongside it. Both are omitted from
        the XML when |None|.

        `svg_fallback` applies only when the picture is an SVG. Word records an SVG
        alongside a raster rendering of it and shows the raster one wherever the vector
        source cannot be used, so passing a PNG or JPEG here is what makes the picture
        appear in an older Word, in a PDF export from some tools, and anywhere else the
        SVG extension is not understood. Without it the fallback refers to the SVG
        itself, which Word 2016 and later render but earlier versions do not.

        `honor_exif_orientation` applies the image's EXIF `Orientation` tag, which a
        photo off a phone or camera almost always carries: the pixels are stored in the
        sensor's native orientation and the tag says how to turn them for display. Every
        image viewer, browser and word processor honours it, and a library that inserts
        pictures and does not produces a visibly wrong document from a correct input
        file. The rotation is written into the DrawingML (`a:xfrm/@rot`) rather than
        into the pixels, so the image part stays byte-identical and the sha1
        deduplication keeps working. Pass |False| for an image whose pixels are already
        rotated *and* which carries the tag anyway — some encoders write both and there
        is no reliable way to detect it.
        """
        inline = self.part.new_pic_inline(
            image_path_or_stream,
            width,
            height,
            description=description,
            title=title,
            svg_fallback=svg_fallback,
            honor_exif_orientation=honor_exif_orientation,
        )
        self._r.add_drawing(inline)
        return InlineShape(inline, self)

    def add_float_picture(
        self,
        image_path_or_stream: str | os.PathLike[str] | IO[bytes],
        width: int | Length | None = None,
        height: int | Length | None = None,
        left: Length | int = 0,
        top: Length | int = 0,
        wrap_type: WD_WRAP_TYPE = WD_WRAP_TYPE.SQUARE,
        behind_text: bool = False,
        relative_from_h: WD_ANCHOR_RELATIVE_FROM_H = WD_ANCHOR_RELATIVE_FROM_H.COLUMN,
        relative_from_v: WD_ANCHOR_RELATIVE_FROM_V = WD_ANCHOR_RELATIVE_FROM_V.PARAGRAPH,
        description: str | None = None,
        title: str | None = None,
        svg_fallback: str | os.PathLike[str] | IO[bytes] | None = None,
        honor_exif_orientation: bool = True,
    ) -> FloatingShape:
        """Return a |FloatingShape| for a picture that text flows around.

        Where :meth:`add_picture` puts the image in the text flow like a character, this
        detaches it: the image is positioned against something on the page and text
        wraps around it, which is what a logo in a corner or a figure beside a paragraph
        needs::

            from docx.shared import Cm
            from docx.enum.shape import WD_ANCHOR_RELATIVE_FROM_H, WD_WRAP_TYPE

            run.add_float_picture(
                "logo.png",
                width=Cm(3),
                left=Cm(1),
                top=Cm(1),
                relative_from_h=WD_ANCHOR_RELATIVE_FROM_H.PAGE,
                wrap_type=WD_WRAP_TYPE.SQUARE,
            )

        `image_path_or_stream`, `width`, `height`, `description`, `title`,
        `svg_fallback` and `honor_exif_orientation` behave exactly as they do for
        :meth:`add_picture`.

        `left` and `top` are the offset from `relative_from_h` and `relative_from_v`,
        which default to the column and the paragraph — where Word puts a picture
        converted from inline to floating. Assign :attr:`.FloatingShape.horizontal_align`
        afterwards to align the shape instead of offsetting it.

        `wrap_type` selects how text flows around the shape. `behind_text` puts the
        shape behind the text rather than over it, which is only meaningful together
        with `WD_WRAP_TYPE.NONE`.

        The shape is anchored to this run's paragraph. A floating shape must be anchored
        to a paragraph in the text flow: Word positions it relative to where the anchor
        falls, so an anchor in a paragraph that moves takes the shape with it.
        """
        anchor = self.part.new_pic_anchor(
            image_path_or_stream,
            width,
            height,
            pos_x=left,
            pos_y=top,
            description=description,
            title=title,
            svg_fallback=svg_fallback,
            honor_exif_orientation=honor_exif_orientation,
        )
        anchor.wrap_type = wrap_type
        anchor.behindDoc = bool(behind_text)
        anchor.positionH.relativeFrom = relative_from_h
        anchor.positionV.relativeFrom = relative_from_v
        self._r.add_drawing(anchor)
        return FloatingShape(anchor, self)

    def add_tab(self) -> None:
        """Add a ``<w:tab/>`` element at the end of the run, which Word interprets as a
        tab character."""
        self._r.add_tab()

    def add_text(self, text: str):
        """Returns a newly appended |_Text| object (corresponding to a new ``<w:t>``
        child element) to the run, containing `text`.

        Compare with the possibly more friendly approach of assigning text to the
        :attr:`Run.text` property.
        """
        t = self._r.add_t(text)
        return _Text(t)

    @property
    def bold(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the text of the run to appear in bold face. When |False|,
        the text unconditionally appears non-bold. When |None| the bold setting for this
        run is inherited from the style hierarchy.
        """
        return self.font.bold

    @bold.setter
    def bold(self, value: bool | None):
        self.font.bold = value

    def add_embedded_object(
        self,
        path_or_stream: str | os.PathLike[str] | IO[bytes],
        *,
        icon: str | os.PathLike[str] | IO[bytes],
        prog_id: str | None = None,
        width: Length | None = None,
        height: Length | None = None,
    ) -> EmbeddedObject:
        """Embed a file in this run as an OLE object and return it.

        An embedded object is a whole file carried inside the document — a spreadsheet,
        a PDF, another document — shown as an icon that opens the original application
        on double-click::

            run.add_embedded_object("budget.xlsx", icon="excel-icon.png",
                                    prog_id="Excel.Sheet.12")

        This is a different thing from :meth:`.Document.add_alt_chunk`, which imports
        content and dissolves it into the document when Word opens the file; an embedded
        object stays a distinct file.

        `icon` is the image Word displays for the object and is required: Word cannot
        render the embedded file itself, and an object with no visual is invisible in
        the document. `width` and `height` size the visual, defaulting to the icon's own
        size.

        `prog_id` is what tells Word which application to launch —
        ``"Excel.Sheet.12"``, ``"Word.Document.12"``, ``"AcroExch.Document"``. Getting
        it wrong produces an object Word shows but cannot open, so it is worth passing
        the right one; the default of ``"Package"`` is Word's generic "some file" entry,
        which prompts the user to choose an application.

        The visual is VML rather than DrawingML, so this shares nothing with
        :meth:`add_picture` beyond relating the icon image in.
        """
        from docx.object import add_embedded_object

        return add_embedded_object(
            self,
            path_or_stream,
            icon=icon,
            prog_id=prog_id,
            width=width,
            height=height,
        )

    @property
    def embedded_objects(self) -> List[EmbeddedObject]:
        """The OLE objects embedded in this run, in document order."""
        from docx.object import iter_embedded_objects

        return iter_embedded_objects(self._r, self)

    def copy_to(
        self,
        paragraph: Paragraph,
        *,
        before: Run | None = None,
        after: Run | None = None,
        missing_style: str = "copy",
    ) -> Run:
        """Return a copy of this run, newly placed in `paragraph`.

        `before` and `after` place the copy relative to an existing run; with neither it
        is appended.

        See :meth:`.Paragraph.copy_to` for what is repaired on the way — relationships,
        drawing ids, bookmarks, and, for a copy into another document, styles.
        """
        from docx.copy import copy_content

        new_r = copy_content(
            self._r, self.part, paragraph.part, missing_style=missing_style
        )

        if before is not None and after is not None:
            raise ValueError("pass at most one of `before` and `after`")
        if before is not None:
            before._r.addprevious(new_r)
        elif after is not None:
            after._r.addnext(new_r)
        else:
            paragraph._p.append(new_r)  # pyright: ignore[reportPrivateUsage]
        return Run(new_r, paragraph)

    def clear(self):
        """Return reference to this run after removing all its content.

        All run formatting is preserved.
        """
        self._r.clear_content()
        return self

    @property
    def contains_page_break(self) -> bool:
        """`True` when one or more rendered page-breaks occur in this run.

        Note that "hard" page-breaks inserted by the author are not included. A hard
        page-break gives rise to a rendered page-break in the right position so if those
        were included that page-break would be "double-counted".

        It would be very rare for multiple rendered page-breaks to occur in a single
        run, but it is possible.
        """
        return bool(self._r.lastRenderedPageBreaks)

    @property
    def font(self) -> Font:
        """The |Font| object providing access to the character formatting properties for
        this run, such as font name and size."""
        return Font(self._element, self)

    @property
    def italic(self) -> bool | None:
        """Read/write tri-state value.

        When |True|, causes the text of the run to appear in italics. When |False|, the
        text unconditionally appears non-italic. When |None| the italic setting for this
        run is inherited from the style hierarchy.
        """
        return self.font.italic

    @italic.setter
    def italic(self, value: bool | None):
        self.font.italic = value

    def iter_inner_content(self) -> Iterator[str | Drawing | RenderedPageBreak]:
        """Generate the content-items in this run in the order they appear.

        NOTE: only content-types currently supported by `python-docx` are generated. In
        this version, that is text and rendered page-breaks. Drawing is included but
        currently only provides access to its XML element (CT_Drawing) on its
        `._drawing` attribute. `Drawing` attributes and methods may be expanded in
        future releases.

        There are a number of element-types that can appear inside a run, but most of
        those (w:br, w:cr, w:noBreakHyphen, w:t, w:tab) have a clear plain-text
        equivalent. Any contiguous range of such elements is generated as a single
        `str`. Rendered page-break and drawing elements are generated individually. Any
        other elements are ignored.
        """
        for item in self._r.inner_content_items:
            if isinstance(item, str):
                yield item
            elif isinstance(item, CT_LastRenderedPageBreak):
                yield RenderedPageBreak(item, self)
            elif isinstance(item, CT_Drawing):  # pyright: ignore[reportUnnecessaryIsInstance]
                yield Drawing(item, self)

    def delete(self) -> None:
        """Remove this run from its paragraph.

        As for `Paragraph.delete()`, a relationship referenced only from this run is
        dropped and any range marker left unmatched is removed.
        """
        delete_element(self._r, self.part)

    def mark_bookmark_range(self, last_run: Run, name: str) -> Bookmark:
        """Return a |Bookmark| named `name` spanning this run through `last_run`.

        The two runs need not be in the same paragraph; a bookmark's delimiters are
        siblings of the content they surround rather than a container for it, which is
        what lets one span paragraphs and table cells.
        """
        from docx.bookmark import Bookmark

        id = self.part.next_bookmark_id
        bookmarkStart = self._r.insert_bookmark_start_above(id, name)
        last_run._r.insert_bookmark_end_below(id)
        return Bookmark(bookmarkStart, self)

    def add_footnote_reference(self, footnote: Footnote) -> None:
        """Add a reference to `footnote` at the end of this run.

        Word renders the reference as the footnote number, superscripted, and places
        the footnote itself at the foot of the page it falls on. A footnote no run
        references does not appear in the rendered document at all.

        The "FootnoteReference" character style is applied to this run when it has no
        character style of its own, since that style is what raises the mark to a
        superscript. Give the run a style beforehand to prevent that, or add the
        reference to a run of its own to keep it off surrounding text::

            footnote = document.footnotes.add_footnote("See Smith (2019).")
            paragraph.add_run().add_footnote_reference(footnote)
        """
        if self._r.style is None:
            self._r.style = "FootnoteReference"
        self._r.add_footnoteReference().id = footnote.footnote_id

    def add_endnote_reference(self, endnote: Endnote) -> None:
        """Add a reference to `endnote` at the end of this run.

        The endnote counterpart of :meth:`add_footnote_reference`, and identical to it
        except that Word places the note at the end of the document or section rather
        than at the foot of the page::

            endnote = document.endnotes.add_endnote("See Smith (2019).")
            paragraph.add_run().add_endnote_reference(endnote)

        The "EndnoteReference" character style is applied to this run when it has no
        character style of its own, since that style is what raises the mark to a
        superscript.
        """
        if self._r.style is None:
            self._r.style = "EndnoteReference"
        self._r.add_endnoteReference().id = endnote.endnote_id

    def mark_comment_range(self, last_run: Run, comment_id: int) -> None:
        """Mark the range of runs from this run to `last_run` (inclusive) as belonging to a comment.

        `comment_id` identfies the comment that references this range.
        """
        # -- insert `w:commentRangeStart` with `comment_id` before this (first) run --
        self._r.insert_comment_range_start_above(comment_id)

        # -- insert `w:commentRangeEnd` and `w:commentReference` run with `comment_id` after
        # -- `last_run`
        last_run._r.insert_comment_range_end_and_reference_below(comment_id)

    @property
    def style(self) -> CharacterStyle:
        """Read/write.

        A |CharacterStyle| object representing the character style applied to this run.
        The default character style for the document (often `Default Character Font`) is
        returned if the run has no directly-applied character style. Setting this
        property to |None| removes any directly-applied character style.
        """
        style_id = self._r.style
        return cast(CharacterStyle, self.part.get_style(style_id, WD_STYLE_TYPE.CHARACTER))

    @style.setter
    def style(self, style_or_name: str | CharacterStyle | None):
        style_id = self.part.get_style_id(style_or_name, WD_STYLE_TYPE.CHARACTER)
        self._r.style = style_id

    @property
    def text(self) -> str:
        """String formed by concatenating the text equivalent of each run.

        Each `<w:t>` element adds the text characters it contains. A `<w:tab/>` element
        adds a `\\t` character. A `<w:cr/>` or `<w:br>` element each add a `\\n`
        character. Note that a `<w:br>` element can indicate a page break or column
        break as well as a line break. Only line-break `<w:br>` elements translate to
        a `\\n` character. Others are ignored. All other content child elements, such as
        `<w:drawing>`, are ignored.

        Assigning text to this property has the reverse effect, translating each `\\t`
        character to a `<w:tab/>` element and each `\\n` or `\\r` character to a
        `<w:cr/>` element. Any existing run content is replaced. Run formatting is
        preserved.
        """
        return self._r.text

    @text.setter
    def text(self, text: str):
        self._r.text = text

    @property
    def underline(self) -> bool | WD_UNDERLINE | None:
        """The underline style for this |Run|.

        Value is one of |None|, |True|, |False|, or a member of :ref:`WdUnderline`.

        A value of |None| indicates the run has no directly-applied underline value and
        so will inherit the underline value of its containing paragraph. Assigning
        |None| to this property removes any directly-applied underline value.

        A value of |False| indicates a directly-applied setting of no underline,
        overriding any inherited value.

        A value of |True| indicates single underline.

        The values from :ref:`WdUnderline` are used to specify other outline styles such
        as double, wavy, and dotted.
        """
        return self.font.underline

    @underline.setter
    def underline(self, value: bool | WD_UNDERLINE | None):
        self.font.underline = value


class _Text:
    """Proxy object wrapping `<w:t>` element."""

    def __init__(self, t_elm: CT_Text):
        super(_Text, self).__init__()
        self._t = t_elm
