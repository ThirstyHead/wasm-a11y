"""|StoryPart| and related objects."""

from __future__ import annotations

import os
from typing import IO, TYPE_CHECKING, Tuple, cast

from docx.image.constants import MIME_TYPE
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.opc.part import XmlPart
from docx.oxml.shape import CT_Anchor, CT_Inline
from docx.shared import Emu, Length, lazyproperty

if TYPE_CHECKING:
    from docx.enum.style import WD_STYLE_TYPE
    from docx.image.image import Image
    from docx.parts.document import DocumentPart
    from docx.styles.style import BaseStyle


class StoryPart(XmlPart):
    """Base class for story parts.

    A story part is one that can contain textual content, such as the document-part and
    header or footer parts. These all share content behaviors like `.paragraphs`,
    `.add_paragraph()`, `.add_table()` etc.
    """

    def get_or_add_image(
        self, image_descriptor: str | os.PathLike[str] | IO[bytes]
    ) -> Tuple[str, Image]:
        """Return (rId, image) pair for image identified by `image_descriptor`.

        `rId` is the str key (often like "rId7") for the relationship between this story
        part and the image part, reused if already present, newly created if not.
        `image` is an |Image| instance providing access to the properties of the image,
        such as dimensions and image type.
        """
        package = self._package
        assert package is not None
        image_part = package.get_or_add_image_part(image_descriptor)
        rId = self.relate_to(image_part, RT.IMAGE)
        return rId, image_part.image

    def get_style(self, style_id: str | None, style_type: WD_STYLE_TYPE) -> BaseStyle:
        """Return the style in this document matching `style_id`.

        Returns the default style for `style_type` if `style_id` is |None| or does not
        match a defined style of `style_type`.
        """
        return self._document_part.get_style(style_id, style_type)

    def get_style_id(
        self, style_or_name: BaseStyle | str | None, style_type: WD_STYLE_TYPE
    ) -> str | None:
        """Return str style_id for `style_or_name` of `style_type`.

        Returns |None| if the style resolves to the default style for `style_type` or if
        `style_or_name` is itself |None|. Raises if `style_or_name` is a style of the
        wrong type or names a style not present in the document.
        """
        return self._document_part.get_style_id(style_or_name, style_type)

    @property
    def next_bookmark_id(self) -> int:
        """Next available `w:id` for a bookmark in this story.

        A bookmark id pairs a `w:bookmarkStart` with its `w:bookmarkEnd`, so it needs to
        be unique only among the bookmarks of this part; `next_id` does not see these,
        because it looks at unprefixed `id` attributes and a bookmark's is `w:id`.
        """
        id_strs = self._element.xpath("//w:bookmarkStart/@w:id")
        used_ids = [int(id_str) for id_str in id_strs if id_str.isdigit()]
        return max(used_ids) + 1 if used_ids else 0

    def new_pic_inline(
        self,
        image_descriptor: str | os.PathLike[str] | IO[bytes],
        width: int | Length | None = None,
        height: int | Length | None = None,
        description: str | None = None,
        title: str | None = None,
        svg_fallback: str | os.PathLike[str] | IO[bytes] | None = None,
        honor_exif_orientation: bool = True,
    ) -> CT_Inline:
        """Return a newly-created `w:inline` element.

        The element contains the image specified by `image_descriptor` and is scaled
        based on the values of `width` and `height`. `description` and `title` are the
        alternative text of the picture. `svg_fallback` is the raster image to show in
        place of an SVG where the SVG cannot be rendered.

        `honor_exif_orientation` applies the image's EXIF `Orientation` as a rotation in
        the DrawingML; see :meth:`.Run.add_picture`.
        """
        rId, image, svg_rId = self._image_rIds(image_descriptor, svg_fallback)
        cx, cy = image.scaled_dimensions(
            width, height, honor_exif_orientation=honor_exif_orientation
        )
        transform = image.drawingml_transform if honor_exif_orientation else (0, False)
        shape_id, filename = self.next_id, image.filename
        return CT_Inline.new_pic_inline(
            shape_id,
            rId,
            filename,
            cx,
            cy,
            description=description,
            title=title,
            svg_rId=svg_rId,
            transform=transform,
        )

    def new_pic_anchor(
        self,
        image_descriptor: str | os.PathLike[str] | IO[bytes],
        width: int | Length | None = None,
        height: int | Length | None = None,
        pos_x: Length | int = 0,
        pos_y: Length | int = 0,
        description: str | None = None,
        title: str | None = None,
        svg_fallback: str | os.PathLike[str] | IO[bytes] | None = None,
        honor_exif_orientation: bool = True,
    ) -> CT_Anchor:
        """Return a newly-created `wp:anchor` element for a floating picture.

        The arguments match :meth:`new_pic_inline`, with `pos_x` and `pos_y` giving the
        offset from the column and paragraph the shape is anchored to.
        """
        rId, image, svg_rId = self._image_rIds(image_descriptor, svg_fallback)
        cx, cy = image.scaled_dimensions(
            width, height, honor_exif_orientation=honor_exif_orientation
        )
        transform = image.drawingml_transform if honor_exif_orientation else (0, False)
        return CT_Anchor.new_pic_anchor(
            self.next_id,
            rId,
            image.filename,
            cx,
            cy,
            Emu(int(pos_x)),
            Emu(int(pos_y)),
            description=description,
            title=title,
            svg_rId=svg_rId,
            transform=transform,
        )

    def _image_rIds(
        self,
        image_descriptor: str | os.PathLike[str] | IO[bytes],
        svg_fallback: str | os.PathLike[str] | IO[bytes] | None,
    ) -> Tuple[str, Image, str | None]:
        """`(rId, image, svg_rId)` for `image_descriptor`.

        For an SVG the vector source goes on the extension and the raster blip alongside
        it is what a consumer that does not understand the extension renders. Dimensions
        always come from the SVG, which is what states the intended display size; the
        fallback is only ever a rendering of it.
        """
        rId, image = self.get_or_add_image(image_descriptor)
        svg_rId = None
        if image.content_type == MIME_TYPE.SVG:
            svg_rId = rId
            if svg_fallback is not None:
                rId, _ = self.get_or_add_image(svg_fallback)
        return rId, image, svg_rId

    @property
    def next_id(self) -> int:
        """Next available positive integer id value in this story XML document.

        The value is determined by incrementing the maximum existing id value. Gaps in
        the existing id sequence are not filled. The id attribute value is unique in the
        document, without regard to the element type it appears on.
        """
        id_str_lst = self._element.xpath("//@id")
        used_ids = [int(id_str) for id_str in id_str_lst if id_str.isdigit()]
        if not used_ids:
            return 1
        return max(used_ids) + 1

    @property
    def document_part(self) -> DocumentPart:
        """The |DocumentPart| of this package.

        A story part is not always the document part — a header or footnote is a story
        too — but the parts they share, styles and numbering among them, hang off the
        document part. This is how a paragraph in any story reaches them.
        """
        return self._document_part

    @lazyproperty
    def _document_part(self) -> DocumentPart:
        """|DocumentPart| object for this package."""
        package = self.package
        assert package is not None
        return cast("DocumentPart", package.main_document_part)
